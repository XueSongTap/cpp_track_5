
local redis = require "resty.redis"

local red = redis:new()

local ok, err = red:connect("127.0.0.1", 6379)
if not ok then
    ngx.log(ngx.ERR, "err:", err)
end

local clientip = ngx.var.remote_addr

-- redis  string\list\hash\set\zset

local exists, err = red:sismember("blacklist", clientip)
if err then
    return ngx.exit(ngx.HTTP_FORBIDDEN)
end

if exists == 1 then
    return ngx.exit(ngx.HTTP_FORBIDDEN)
end
